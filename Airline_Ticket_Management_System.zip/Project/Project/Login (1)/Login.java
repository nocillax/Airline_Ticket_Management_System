//package Login;
import java.io.*;
/*import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;*/
import java.util.Scanner;   

public class Login
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        File f1 = new File("AdminLogin.txt");
        File f2 = new File("CustomerLogin.txt");


        while(true)
        {
            System.out.println("");

			System.out.println("*******************");
	        System.out.println("*    LOGIN PAGE   *");
	        System.out.println("*******************");

			System.out.println("Choose Any of The Operations You Want to Perform.");
			
			System.out.println("");

            System.out.println("1. ADMIN LOGIN.");
			System.out.println("2. SIGN UP.");
            System.out.println("3. LOGIN.");
			System.out.println("4. EXIT.");

			System.out.println("");

			System.out.print("Please Enter Your Choice: ");

			int choice = sc.nextInt(); 

			sc.nextLine();

            cls();

            switch(choice)
			{
                case 1:
                    FileReader fr;
				    BufferedReader br;

                    System.out.println("");

                    System.out.println("*****************");
                    System.out.println("*  ADMIN LOGIN  *"); 
                    System.out.println("*****************");

                    System.out.print("Username: ");
                    String usna1 = sc.nextLine();

                    System.out.print("Password: ");
                    String pass1 = sc.nextLine();
                        
                    try 
                    {
                        fr = new FileReader(f1);
						br = new BufferedReader(fr);

                        String text = "";

						while((text = br.readLine()) != null)
						{

                            if (text.contains(usna1) || text.contains(pass1))
                            {
                                System.out.println("");

                                cls();

                                System.out.println("Successfully Logged In.");
                            }

                            else
                            {
                                System.out.println("");

                                cls();

                                System.out.println("Invalid Username or Password.");
                            }
                            break;
                        }
                    }
    
                    catch(Exception ex)
                    {
                        System.out.println("Invalid Username or Password.");
                    }

                break;
                
                case 2:
                    
                        System.out.println("");

                        System.out.println("*************");
                        System.out.println("*  SIGN UP  *"); 
                        System.out.println("*************");

                        System.out.print("Username: ");
                        String usna = sc.nextLine();

                        System.out.print("Pnone Number: ");
                        String pnnu = sc.nextLine();

                        System.out.print("Email: ");
                        String ema = sc.nextLine();

                        System.out.print("Password: ");
                        String pass = sc.nextLine();

                        System.out.print("Confirm Password: ");
                        String cpass = sc.nextLine();
                        
                        FileWriter fw;

                            try 
                            {
                                fw = new FileWriter(f2, true);
                                
                                    if(pass.equals(cpass))
                                    {
                                        fw.write("Username- " + usna + "\n");
                                        fw.write("Pnone Number- " + pnnu + "\n");
                                        fw.write("Email- " + ema + "\n");
                                        fw.write("Password- " + pass + "\n");
                                        fw.write("\n");

                                        System.out.println("");

                                        cls();

                                        System.out.println("Successfully Signed Up.");  

                                        fw.close();

                                        break;
                                        
                                    }

                                    else
                                    {
                                        System.out.println("");

                                        cls();

                                        System.out.println("Passwords are not same!!!");
                                    }    
                            }

                            catch(Exception ex) 
                            {
                                System.out.println("Error while writing in file");
                            }

                        break;
                    
                    

                case 3:
                    System.out.println("");

                    System.out.println("***********");
                    System.out.println("*  LOGIN  *"); 
                    System.out.println("***********");

                    System.out.print("Username: ");
                    String usna2 = sc.nextLine();

                    System.out.print("Password: ");
                    String pass2 = sc.nextLine();
                        
                    try 
                    {
                        fr = new FileReader(f1);
						br = new BufferedReader(fr);

                        String text = "";

						while((text = br.readLine()) != null)
						{

                            if (text.contains(usna2) || text.contains(pass2))
                            {
                                System.out.println("");

                                cls();

                                System.out.println("Successfully Logged In.");
                            }

                            else 
                            {
                                System.out.println("Invalid Username or Password.");
                            }
                            break;
                        }
                    }
    
                    catch(Exception ex)
                    {
                        System.out.println("Invalid Username or Password.");
                    }

                break;    

				//Write
				

                //Exit
                case 4:

                System.out.println("");

                System.out.println("******************************************************");
                System.out.println("*            Thanks for Using The Program            *");
                System.out.println("******************************************************");

                System.out.println("");

                System.exit(0);

                break;

            default:

                System.out.println("");

                cls();

                System.out.println("Invalid Choice!");
                	
            }
        }
    }

    public static void cls()
      {
          try
          {
                new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
          }
          catch(Exception e)
          {
                System.out.println(e);
          }
      }
}
