public class Customer extends User{
    
}
