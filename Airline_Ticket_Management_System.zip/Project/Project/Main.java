import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    


    public static void main (String[] args){
        
        Scanner sc = new Scanner(System.in);
        Flights fl = new EconomyClassFlights();


        boolean done = false;
        while (!done){
            int flightNo = 0;

            try{
                System.out.print("Enter Flight No : ");
                flightNo = sc.nextInt();
                done = true;
                
            }
            catch (InputMismatchException ime) {
                sc.nextLine();
                System.out.println("Please Enter A Valid Number. ");
            }
            fl.setFlightNo(flightNo);
            System.out.println(fl.getFlightName());
        } 
     
        while(true){
            try {
                
                System.out.print("Enter Flight Name : ");
                String flightName = sc.nextLine();
                fl.setFlightName(flightName);
                System.out.println(fl.getFlightName());
                break;
            }
            catch (EmptyStringException ese) {
                System.out.println(ese.getMessage());
            }       
        } 
        while(true){ 
            try {
                
                System.out.print("Enter Departure Location : ");
                String departureLocation = sc.nextLine();
                fl.setDepartureLocation(departureLocation);
                System.out.println(fl.getDepartureLocation());
                break;
            }
            catch (EmptyStringException ese) {
                System.out.println(ese.getMessage());
            }   
        }
        
        
        
        while(true){ 
            try {
                
                System.out.print("Enter Departure Airport : ");
                String departureAirport = sc.nextLine();
                fl.setDepartureAirport(departureAirport);
                System.out.println(fl.getDepartureAirport());
                break;
            }
            catch (EmptyStringException ese) {
                System.out.println(ese.getMessage());
            }   
        } 
        
        while(true){ 
            try {
                
                System.out.print("Enter Destination Location : ");
                String destinationLocation = sc.nextLine();
                fl.setDestinationLocation(destinationLocation);
                System.out.println(fl.getDestinationLocation());
                break;
            }
            catch (EmptyStringException ese) {
                System.out.println(ese.getMessage());
            }
        } 
        
        while(true){ 
            try {
                
                System.out.print("Enter Destination Airport : ");
                String destinationAirport = sc.nextLine();
                fl.setDestinationAirport(destinationAirport);
                System.out.println(fl.setDestinationAirport());
                break;
            }
            catch (EmptyStringException ese) {
                System.out.println(ese.getMessage());
            }
        } 
        

        
        
        System.out.print("Enter Flight Duration : ");
        double travelDuration = sc.nextDouble();
        System.out.print("Enter Ticket Price : ");
        double ticketPrice = sc.nextDouble();
        System.out.print("Enter Number of Economy Seats : ");
        int economySeats = sc.nextInt();
        System.out.print("Enter Number of Persons : ");
        int noOfPerson = sc.nextInt(); 

        Flights f = new EconomyClassFlights(flightNo, flightName, departureLocation, departureAirport, destinationLocation, destinationAirport, travelDuration, ticketPrice, economySeats, noOfPerson);

        File f3 = new File("FlightDetails.txt");

        

        try {
        f3.createNewFile();
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
        System.out.println("Flight Class - 1. Economy Class \t2. Business Class");
        int input = sc.nextInt();
        if(input == 1) {}
        else if(input == 2){} 

        
            System.out.print("Enter Flight No : ");
            flightNo = sc.nextInt();
            try{
            System.out.print("Enter Flight Name : ");
            sc.nextLine();
            flightName = sc.nextLine();
            if (flightName == null || flightName.isEmpty()){
                throw new EmptyStringException("Field Cannot Be Empty");
            }
        }
        catch(EmptyStringException ese){
            ese.printStackTrace();
        }
            System.out.print("Enter Departure Location : ");
            departureLocation = sc.nextLine();
            System.out.print("Enter Departure Airport : ");
            departureAirport = sc.nextLine();
            System.out.print("Enter Destination Location : ");
            destinationLocation = sc.nextLine();
            System.out.print("Enter Destination Airport : ");
            destinationAirport = sc.nextLine();
            System.out.print("Enter Flight Duration : ");
            travelDuration = sc.nextDouble();
            System.out.print("Enter Ticket Price : ");
            ticketPrice = sc.nextDouble();
            System.out.print("Enter Number of Economy Seats : ");
            economySeats = sc.nextInt();
        

        try {
        FileWriter fw = new FileWriter(f3, true);
        BufferedWriter bw = new BufferedWriter(fw);

        bw.write("Flight No. : " + flightNo);
        bw.write("Flight Name : " + flightName);
        bw.write("Flight Type : " + "Economy Class");
        bw.write("Departure Location : " + departureLocation);
        bw.write("Departure Airport : " + departureAirport);
        bw.write("Destination Location : " + destinationLocation);
        bw.write("Destination Airport : " + destinationAirport);
        bw.write("Duration of Flight : " + travelDuration);
        bw.write("Ticket Price : " + ticketPrice);
        bw.write("Number of Economy Seats : " + economySeats);
        bw.close();
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
        

        Flights f = new EconomyClassFlights(flightNo, flightName, departureLocation, departureAirport, destinationLocation, destinationAirport, travelDuration, ticketPrice, economySeats, noOfPerson);
        f.bookSeats(noOfPerson);
        f.calculateTicketPrice();
        f.show();
        System.out.println(f.getSeats());
        System.out.println();
    
    }
}   
