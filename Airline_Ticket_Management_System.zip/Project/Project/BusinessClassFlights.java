public class BusinessClassFlights extends Flights{

    protected int noOfPerson;
    protected int businessSeats;

    public BusinessClassFlights(int flightNo, String flightName, String departureLocation, String departureAirport, String destinationLocation, String destinationAirport, double travelDuration, double ticketPrice, int businessSeats, int noOfPerson){
        super(flightNo, flightName, departureLocation, departureAirport, destinationLocation, destinationAirport, travelDuration, ticketPrice);
        this.noOfPerson = noOfPerson;
        this.businessSeats = businessSeats;
        type = 1;
    }

    public void bookSeats (int noOfPerson){
        this.businessSeats = businessSeats - noOfPerson;
        
    }

    public double calculateTicketPrice(){
        return ticketPrice * noOfPerson;
    }

    public int getSeats(){
        return this.businessSeats;
    }
    
    public void show(){
        System.out.println("Flight No. : " + flightNo);
        System.out.println("Flight Name : " + flightName);
        System.out.println("Flight Type : " + "Business Class");
        System.out.println("Departure Location : " + departureLocation);
        System.out.println("Departure Airport : " + departureAirport);
        System.out.println("Destination Location : " + destinationLocation);
        System.out.println("Destination Airport : " + destinationAirport);
        System.out.println("Duration of Flight : " + travelDuration);
        System.out.println("Number of Person : " + noOfPerson);
        System.out.println("Total Ticket Cost : " + calculateTicketPrice());
    }
}
