public class Admin extends User{

    

}
