class EmptyStringException extends RuntimeException {
    private String message;
    public EmptyStringException(String message) {
         this.message = message;
    }
    public String getMessage() { return message; }
}