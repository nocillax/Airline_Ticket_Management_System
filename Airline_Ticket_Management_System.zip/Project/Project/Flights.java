import java.util.EmptyStackException;
import java.util.InputMismatchException;

public abstract class Flights {

    protected int type;
    protected int flightNo;
    protected String flightName;
    protected String departureLocation;
    protected String departureAirport;
    protected String destinationLocation;
    protected String destinationAirport;
    protected double travelDuration;
    protected double ticketPrice;

    Flights(){}

    Flights(int flightNo, String flightName, String departureLocation, String departureAirport, String destinationLocation, String destinationAirport, double travelDuration, double ticketPrice) { 
    
        this.flightNo = flightNo;
        this.flightName = flightName;
        this.departureLocation = departureLocation;
        this.departureAirport = departureAirport;
        this.destinationLocation = destinationLocation;
        this.destinationAirport = destinationAirport;
        this.travelDuration = travelDuration;
        this.ticketPrice = ticketPrice;
    }

    public void setFlightNo(int flightNo) {this.flightNo = flightNo;}

    public void setFlightName(String flightName)  {
        if (flightName == null || flightName.isEmpty()) { throw new EmptyStringException("Field Cannot Be Empty"); }
        else { this.flightName = flightName; }
    }
    public void setDepartureLocation(String departureLocation) {
        if (departureLocation == null || departureLocation.isEmpty()) { throw new EmptyStringException("Field Cannot Be Empty"); }
        else { this.departureLocation = departureLocation; }
    }
    public void setDepartureAirport(String departureAirport) {
    if (departureAirport == null || departureAirport.isEmpty()) { throw new EmptyStringException("Field Cannot Be Empty"); }
    else { this.departureAirport = departureLocation; }
    }
    public void setDestinationLocation(String destinationLocation){ 
    if (destinationLocation == null || destinationLocation.isEmpty()) { throw new EmptyStringException("Field Cannot Be Empty"); }
    else { this.destinationLocation = destinationLocation; }
    }
    public void setDestinationAirport(String destinationAirport) {
    if (destinationAirport == null || destinationAirport.isEmpty()) { throw new EmptyStringException("Field Cannot Be Empty"); }
    else { this.destinationAirport = destinationAirport; }
    }
    public void setTravelDuration(double travelDuration) {this.travelDuration = travelDuration;}
    public void setTicketPrice(double ticketPrice) {this.ticketPrice = ticketPrice;}

    public int getFlightNo() {return flightNo;}
    public String getFlightName() {return flightName;}
    public String getDepartureLocation() {return departureLocation;}
    public String getDepartureAirport() {return departureAirport;}
    public String getDestinationLocation() {return destinationLocation;}
    public String getDestinationAirport() {return destinationAirport;}
    public double getTravelDuration() {return travelDuration;}
    public double getTicketPrice() {return ticketPrice;}

    public abstract double calculateTicketPrice();
    public abstract void bookSeats(int noOfPerson);
    public abstract int getSeats();
    public abstract void show();
}