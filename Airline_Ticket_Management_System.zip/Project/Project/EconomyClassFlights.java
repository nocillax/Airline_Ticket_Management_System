public class EconomyClassFlights extends Flights{

    protected int noOfPerson;
    protected int economySeats;

    public EconomyClassFlights(){};
    public EconomyClassFlights(int flightNo, String flightName, String departureLocation, String departureAirport, String destinationLocation, String destinationAirport, double travelDuration, double ticketPrice,int economySeats, int noOfPerson) {
        super(flightNo, flightName, departureLocation, departureAirport, destinationLocation, destinationAirport, travelDuration, ticketPrice);
        this.noOfPerson = noOfPerson;
        this.economySeats = economySeats;
        type = 1;
    }

   

    public void bookSeats (int noOfPerson){
        this.economySeats = economySeats - noOfPerson;
        
    }

    public double calculateTicketPrice(){
        return ticketPrice * noOfPerson;
    }

    public int getSeats(){
        return this.economySeats;
    }

    public void show(){
        System.out.println("Flight No. : " + flightNo);
        System.out.println("Flight Name : " + flightName);
        System.out.println("Flight Type : " + "Economy Class");
        System.out.println("Departure Location : " + departureLocation);
        System.out.println("Departure Airport : " + departureAirport);
        System.out.println("Destination Location : " + destinationLocation);
        System.out.println("Destination Airport : " + destinationAirport);
        System.out.println("Duration of Flight : " + travelDuration);
        System.out.println("Number of Person : " + noOfPerson);
        System.out.println("Total Ticket Cost : " + calculateTicketPrice());
    }

    /* public void setFlightNo(int flightNo) {this.flightNo = flightNo;}
    public void setFlightName(String flightName) throws EmptyStringException {
        if (flightName == null || flightName.isEmpty()) {throw new EmptyStringException("Field Cannot Be Empty");}
        else {this.flightName = flightName;}

    }
    public void setDepartureLocation(String departureLocation) {this.departureLocation = departureLocation;}
    public void setDepartureAirport(String departureAirport) {this.departureAirport = departureAirport;}
    public void setDestinationLocation(String destinationLocation) {this.destinationLocation = destinationLocation;}
    public void setDestinationAirport(String destinationAirport) {this.destinationAirport = destinationAirport;}
    public void setTravelDuration(double travelDuration) {this.travelDuration = travelDuration;}
    public void setTicketPrice(double ticketPrice) {this.ticketPrice = ticketPrice;} */

    public void setEconomySeats(int economySeats) {this.economySeats = economySeats;}
    public void setNoOfPersons(int noOfPerson) {this.noOfPerson = noOfPerson;}

    public int getFlightNo() {return flightNo;}
    public String getFlightName() {return flightName;}
    public String getDepartureLocation() {return departureLocation;}
    public String getDepartureAirport() {return departureAirport;}
    public String getDestinationLocation() {return destinationLocation;}
    public String getDestinationAirport() {return destinationAirport;}
    public double getTravelDuration() {return travelDuration;}
    public double getTicketPrice() {return ticketPrice;}

}
