public class User {

    int type;
    int flightNo;
    String flightName;
    String departureLocation;
    String departureAirport;
    String destinationLocation;
    String destinationAirport;
    double travelDuration;
    double ticketPrice;
    int economySeats;
    int businessSeats;

    Flights flights [];

    public User() {}

    public User (int sz){
        flights = new Flights[sz];
    }

    public void addFlight(Flights a){
        int flag = 0;
        for(int i=0; i<flights.length; i++){
            if(flights[i] == null){
                flights[i] = a;
                flag = 1;
                break;
            }
        }
        if (flag == 1){
            System.out.println();
            System.out.println("----Flight Details Added Successfully----");
        }
        else {
            System.out.println();
            System.out.println("----Error Occurred While Adding Flight Details----");
        }
    }

    public Flights getFlight(int flightNo){
        Flights a = null;
        int flag = 0;
        for(int i=0; i<flights.length; i++){
            if (flights[i] != null){
                if(flights[i].getFlightNo() == flightNo ){
                    a = flights[i];
                    flag = 1;
                    break;
                }
            }
        }
        if (flag == 0){
            System.out.println();
            System.out.println("Flight Details Does Not Exist");
        }
        return a;
       
    }

    public void showAllFlights(){
        System.out.println();
        System.out.println("------------------");
        for (int i = 0; i < flights.length; i++){
            if(flights[i] != null){
                flights[i].show();
            }
        }
    }

}
